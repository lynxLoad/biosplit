extends Node2D
class_name CharacterBase

signal turn_finished
signal damaged(amount: float)
signal healed(amount: float)   # ← новый
signal died
signal retreat_started
signal block_started
signal block_ended
signal hit_blocked(amount: float)
signal dodge_started
signal attack_dodged(amount: float)
signal attack_missed
signal ap_changed(current: float, delta: float)
signal attack_started(ability: Ability)

enum State { IDLE, MOVING_TO_IDLE, ATTACKING, RETREATING, BLOCKING, DODGING, HIT, DEAD }
enum HitShakePreset { LIGHT, MEDIUM, HEAVY, CRITICAL, JAB, MAGIC, BLOCK_HIT, CUSTOM, NONE }

## Формат: [distance, duration, oscillations, decay, return_mult]
const HIT_SHAKE_PRESETS := {
	HitShakePreset.LIGHT:     [6.0,  0.18, 4, 0.55, 1.2],
	HitShakePreset.MEDIUM:    [14.0, 0.30, 7, 0.65, 1.5],
	HitShakePreset.HEAVY:     [24.0, 0.45, 6, 0.78, 1.6],
	HitShakePreset.CRITICAL:  [32.0, 0.55, 9, 0.80, 2.0],
	HitShakePreset.JAB:       [8.0,  0.12, 3, 0.45, 1.0],
	HitShakePreset.MAGIC:     [10.0, 0.40, 8, 0.70, 1.8],
	HitShakePreset.BLOCK_HIT: [6.0,  0.20, 5, 0.60, 1.3],
	HitShakePreset.NONE:      [0.0,  0.0,  0, 0.0,  0.0],
}

const ANIM_IDLE := &"idle"
const ANIM_ATTACK := &"attack"
const ANIM_DAMAGE := &"damage"
const ANIM_DEATH := &"death"
const ANIM_BLOCK := &"block"
const ANIM_WAIT_TIMEOUT := 3.0
const CORPSE_GROUP := &"corpses"

# ── stats & weapon ──
@export_group("Stats & Weapon")
@export var character_stats: CharacterStats
@export var weapon: Weapon

# ── combat geometry ──
@export_group("Combat Geometry")
@export var strike_distance: float = 80.0
@export var pixels_per_unit: float = 100.0

# ── timing ──
@export_group("Timing")
@export var min_phase_duration: float = 0.08
@export var max_phase_duration: float = 1.5

# ── animations ──
@export_group("Animations")
@export var animation_frame_damage: int = 1
## Веса способностей для рандомного выбора. Ключ — Ability.name.
@export var _attack_weights: Dictionary[StringName, int] = {}

# ── attack juice ──
@export_group("Attack Juice")
@export_range(0.0, 16.0) var attack_lunge_distance: float = 4.0
@export_range(0.0, 16.0) var attack_recoil_distance: float = 5.0

# ── hit shake ──
@export_group("Hit Shake")
@export var hit_shake_preset: HitShakePreset = HitShakePreset.JAB
@export_range(0.0, 0.5) var hit_shake_distance_jitter: float = 0.1
@export_range(0.0, 0.5) var hit_shake_duration_jitter: float = 0.0
@export_range(0.0, 0.5) var hit_shake_decay_jitter: float = 0.0

@export_subgroup("Custom Shake (используется только при preset = CUSTOM)")
@export var hit_shake_distance: float = 14.0
@export var hit_shake_duration: float = 0.3
@export_range(0, 10) var hit_shake_oscillations: int = 7
@export_range(0.0, 1.0) var hit_shake_decay: float = 0.65
@export var hit_shake_return_mult: float = 1.5

# ── hit flash ──
@export_group("Hit Flash")
@export var flash_color: Color = Color(1.0, 0.4, 0.4, 1.0)
@export var flash_in_duration: float = 0.05
@export var flash_out_duration: float = 0.1

# ── hitstop ──
@export_group("Hitstop")
## Включает глобальное замедление времени при получении урона.
@export var hitstop_enabled: bool = true
## Множитель времени во время хитстопа (0.0 — полная заморозка).
@export_range(0.0, 1.0) var hitstop_time_scale: float = 0.1
## Базовая длительность хитстопа в реальных секундах.
@export var hitstop_base_duration: float = 0.06
## Дополнительная длительность за единицу урона (0 = без привязки к урону).
@export var hitstop_per_damage: float = 0.0
## Верхний предел длительности, чтобы не «залипать» на больших ударах.
@export var hitstop_max_duration: float = 0.2

@export_subgroup("Block Hitstop")
## Хитстоп при успешном блоке (когда поглощено > 0).
@export var block_hitstop_enabled: bool = true
## Множитель времени во время блока.
@export_range(0.0, 1.0) var block_hitstop_time_scale: float = 0.2
## Базовая длительность хитстопа от блока (реальные секунды).
@export var block_hitstop_base_duration: float = 0.05
## Дополнительная длительность за единицу поглощённого урона.
@export var block_hitstop_per_damage: float = 0.0
## Верхний предел длительности блочного хитстопа.
@export var block_hitstop_max_duration: float = 0.15

@export_subgroup("Dodge Hitstop")
## Хитстоп при успешном дэше (атака промахнулась по iframe).
@export var dodge_hitstop_enabled: bool = true
## Множитель времени во время дэша.
@export_range(0.0, 1.0) var dodge_hitstop_time_scale: float = 0.15
## Базовая длительность хитстопа от дэша (реальные секунды).
@export var dodge_hitstop_base_duration: float = 0.08
## Дополнительная длительность за единицу «отменённого» урона (0 = без привязки).
@export var dodge_hitstop_per_damage: float = 0.0
## Верхний предел длительности дэш-хитстопа.
@export var dodge_hitstop_max_duration: float = 0.2

@export_subgroup("Death Hitstop")
## Хитстоп при летальном ударе. Заменяет обычный (не суммируется с ним).
@export var death_hitstop_enabled: bool = true
## Множитель времени во время смерти. 0.0 = полный фриз-фрейм.
@export_range(0.0, 1.0) var death_hitstop_time_scale: float = 0.0
## Базовая длительность хитстопа от смерти (реальные секунды).
@export var death_hitstop_base_duration: float = 0.18
## Дополнительная длительность за единицу летального урона (0 = без привязки).
@export var death_hitstop_per_damage: float = 0.0
## Верхний предел длительности death-хитстопа.
@export var death_hitstop_max_duration: float = 0.4

var _hitstop_active: bool = false
var _hitstop_remaining: float = 0.0
var _hitstop_target_time_scale: float = 1.0

# ── block ──
@export_group("Block")
@export var block_max_absorbed_damage: float = 0.0
@export var block_shake_distance: float = 6.0
@export_range(0.0, 16.0) var block_recoil_distance: float = 4.0

@export_subgroup("Block Flash")
@export var block_flash_color: Color = Color(0.4, 0.65, 1.0, 1.0)
@export var block_flash_in_duration: float = 0.03
@export var block_flash_out_duration: float = 0.12

# ── action points ──
@export_group("Action Points")
@export var max_ap: float = 5.0

var current_ap: float = 0.0

# ── death: knockback ──
@export_group("Death Knockback")
@export var death_knockback_distance: float = 120.0
@export var death_knockback_speed: float = 500.0
@export var death_knockback_angle_jitter: float = 0.2
@export var death_knockback_distance_jitter: float = 0.3
@export_range(0.0, 32.0) var death_arc_height: float = 8.0

@export_group("Death Landing")
@export var death_min_corpse_distance: float = 150.0
@export_range(1, 40) var death_landing_attempts: int = 40
@export var death_landing_bounds: Rect2 = Rect2()
@export var death_landing_viewport_pad: Vector2 = Vector2(60.0, 60.0)

@export_group("Death Corpse & Z")
@export var death_disappear: bool = false
@export_range(0.0, 1.0) var death_corpse_alpha: float = 1.0
@export var death_flying_z: int = 2000
@export var death_corpse_z: int = -1
@export_range(0, 4096) var death_corpse_z_sort_span: int = 1500
@export var death_corpse_sort_y_range: Vector2 = Vector2.ZERO
@export var death_fade_duration: float = 0.5
@export var death_fade_delay: float = 0.0
@export var z_attack_priority: int = 1000

@onready var animated_sprite: AnimatedSprite2D = $AnimatedSprite2D

var target: CharacterBase
var idle_point: Vector2
var health: float
var _state: State = State.IDLE
var _action_id: int = 0
var _z_before_attack: int = 0
var _active_tween: Tween
var _hit_shake_tween: Tween
var _flash_tween: Tween
var _idle_bob_tween: Tween
var _recoil_tween: Tween
var _block_absorbed: float = 0.0
var _last_hit_from: Vector2 = Vector2.INF
var _sprite_base_position: Vector2
var _idle_point_set: bool = false
var _corpse_landing_pos: Vector2 = Vector2.INF
var _invulnerable: bool = false

func _ready() -> void:
	current_ap = clampf(current_ap, 0.0, max_ap)
	if character_stats == null:
		push_error("CharacterBase: character_stats не задан на %s" % name)
		character_stats = CharacterStats.new()
	character_stats = character_stats.duplicate()
	health = character_stats.max_health
	if not _idle_point_set:
		reset_idle_point()
	if animated_sprite:
		_sprite_base_position = animated_sprite.position
		_play_anim(ANIM_IDLE)

func _exit_tree() -> void:
	# Аварийный сброс, если сцена выгружается посреди хитстопа.
	if _hitstop_active:
		_hitstop_active = false
		_hitstop_remaining = 0.0
		_hitstop_target_time_scale = 1.0
		Engine.time_scale = 1.0

# ── hitstop ──

func _trigger_hitstop(amount: float = 0.0, time_scale_override: float = -1.0) -> void:
	if not hitstop_enabled:
		return
	var duration := hitstop_base_duration + hitstop_per_damage * maxf(amount, 0.0)
	if duration <= 0.0:
		return
	duration = minf(duration, hitstop_max_duration)
	var ts := hitstop_time_scale if time_scale_override < 0.0 else time_scale_override
	_apply_hitstop(duration, ts)

func _trigger_block_hitstop(absorbed: float = 0.0) -> void:
	if not block_hitstop_enabled:
		return
	var duration := block_hitstop_base_duration + block_hitstop_per_damage * maxf(absorbed, 0.0)
	if duration <= 0.0:
		return
	duration = minf(duration, block_hitstop_max_duration)
	_apply_hitstop(duration, block_hitstop_time_scale)

func _trigger_dodge_hitstop(amount: float = 0.0) -> void:
	if not dodge_hitstop_enabled:
		return
	var duration := dodge_hitstop_base_duration + dodge_hitstop_per_damage * maxf(amount, 0.0)
	if duration <= 0.0:
		return
	duration = minf(duration, dodge_hitstop_max_duration)
	_apply_hitstop(duration, dodge_hitstop_time_scale)

func _trigger_death_hitstop(amount: float = 0.0) -> void:
	if not death_hitstop_enabled:
		return
	var duration := death_hitstop_base_duration + death_hitstop_per_damage * maxf(amount, 0.0)
	if duration <= 0.0:
		return
	duration = minf(duration, death_hitstop_max_duration)
	_apply_hitstop(duration, death_hitstop_time_scale)

func _apply_hitstop(duration: float, time_scale: float) -> void:
	_hitstop_remaining = maxf(_hitstop_remaining, duration)
	var new_ts := minf(_hitstop_target_time_scale, time_scale) if _hitstop_active else time_scale
	_hitstop_target_time_scale = new_ts
	if _hitstop_active:
		Engine.time_scale = _hitstop_target_time_scale
		return
	_hitstop_active = true
	_run_hitstop()

func _run_hitstop() -> void:
	Engine.time_scale = _hitstop_target_time_scale
	while _hitstop_remaining > 0.0:
		var remaining := _hitstop_remaining
		# ignore_time_scale = true → таймер честный в реальном времени.
		await get_tree().create_timer(remaining, true, false, true).timeout
		# Вычитаем отработанное, а не обнуляем — так расширение хитстопа
		# во время await корректно увеличивает оставшееся время.
		_hitstop_remaining = maxf(0.0, _hitstop_remaining - remaining)
	Engine.time_scale = 1.0
	_hitstop_active = false
	_hitstop_target_time_scale = 1.0

# ── idle point ──

func set_idle_point(point: Vector2) -> void:
	idle_point = point
	_idle_point_set = true

func reset_idle_point() -> void:
	idle_point = global_position
	_idle_point_set = true

# ── state queries ──

func is_busy() -> bool:
	return _state != State.IDLE and _state != State.DEAD

func is_dead() -> bool:
	return _state == State.DEAD

func is_attacking() -> bool:
	return _state == State.ATTACKING or _state == State.RETREATING

func is_moving_to_idle() -> bool:
	return _state == State.MOVING_TO_IDLE

func is_blocking() -> bool:
	return _state == State.BLOCKING

func is_invulnerable() -> bool:
	return _invulnerable

func is_dodging() -> bool:
	return _state == State.DODGING

func get_health() -> float:
	return health

func get_max_health() -> float:
	return character_stats.max_health if character_stats else 0.0

func set_z_priority(priority: int) -> void:
	z_index = priority

func get_block_damage_reduction() -> float:
	return maxf(0.0, character_stats.block_damage_reduction) if character_stats else 0.0

func get_corpse_anchor() -> Vector2:
	return _corpse_landing_pos if _corpse_landing_pos != Vector2.INF else global_position

# ── action points ──

func get_ap() -> float:
	return current_ap

func get_max_ap() -> float:
	return max_ap

func can_use_ability(ability: Ability) -> bool:
	return ability != null and ability.can_use(current_ap)

func _apply_ap_delta(delta: float) -> void:
	if is_zero_approx(delta):
		return
	var old := current_ap
	current_ap = clampf(current_ap + delta, 0.0, max_ap)
	if not is_equal_approx(current_ap, old):
		ap_changed.emit(current_ap, current_ap - old)

# ── public actions ──

func attack(enemy: CharacterBase, ability: Ability = null) -> void:
	if _state not in [State.IDLE, State.MOVING_TO_IDLE]:
		return
	if not is_instance_valid(enemy) or enemy.is_dead():
		return
	if weapon == null:
		push_warning("CharacterBase: attack() без weapon на %s" % name)
		return
	if ability == null:
		ability = _pick_ability()
	if ability == null:
		return
	if not ability.can_use(current_ap):
		return

	var id := _begin_action()
	_state = State.ATTACKING
	target = enemy
	_z_before_attack = z_index
	z_index = z_attack_priority

	var start := global_position
	var anchor := _resolve_strike_anchor(enemy)
	var dir := _safe_dir(start - anchor, Vector2.RIGHT)
	var strike_pos := start
	if start.distance_to(anchor) > strike_distance:
		strike_pos = anchor + dir * strike_distance
	var speed_px := maxf(character_stats.speed, 0.01) * pixels_per_unit
	var approach_speed_px := speed_px * _approach_speed_mult()

	# ── prepare ДО подхода (для врагов) ──
	if _should_prepare_before_approach() and ability.has_prepare() and _has_anim(ability.prepare_name):
		_play_anim(ability.prepare_name)
		await _await_anim_end(ability.prepare_name, id)
		if id != _action_id:
			return

	# ── подход ──
	if start.distance_to(strike_pos) > 1.0:
		if not (await _move_to(strike_pos, approach_speed_px, id)):
			return
		var retarget_anchor := _resolve_strike_anchor(enemy)
		var to_anchor := global_position - retarget_anchor
		var retarget_pos := global_position
		if to_anchor.length() > strike_distance:
			retarget_pos = retarget_anchor + to_anchor.normalized() * strike_distance
		if global_position.distance_to(retarget_pos) > 2.0:
			if not (await _move_to(retarget_pos, approach_speed_px, id)):
				return
		dir = _safe_dir(global_position - _resolve_strike_anchor(enemy), Vector2.RIGHT)

	# ── prepare ПОСЛЕ подхода (для игрока — как было) ──
	if not _should_prepare_before_approach() and ability.has_prepare() and _has_anim(ability.prepare_name):
		_play_anim(ability.prepare_name)
		await _await_anim_end(ability.prepare_name, id)
		if id != _action_id:
			return

	# ── анимация атаки с первого кадра ──
	var attack_anim := _resolve_attack_anim(ability)
	_play_anim(attack_anim)
	attack_started.emit(ability)
	_play_attack_lunge(dir)

	# ── удар — сразу на первом кадре атаки ──
	if is_instance_valid(enemy) and not enemy.is_dead():
		_apply_ap_delta(ability.ap_delta)
		var in_range := _is_strike_in_range(enemy, dir)
		var dodged := enemy.is_dodging() and enemy.is_invulnerable()
		if in_range or dodged:
			enemy.take_damage(ability.damage, global_position)
		else:
			attack_missed.emit()
	_play_attack_recoil(dir)
	await _await_anim_end(attack_anim, id)
	if id != _action_id:
		return

	# ── отход ──
	retreat_started.emit()
	_state = State.RETREATING
	var retreat_time := clampf(
		global_position.distance_to(idle_point) / speed_px,
		min_phase_duration, max_phase_duration
	)
	if not (await _tween_self_to(idle_point, retreat_time, id, Tween.EASE_IN)):
		return
	z_index = _z_before_attack
	_state = State.IDLE
	_play_anim(ANIM_IDLE)
	turn_finished.emit()

func _is_strike_in_range(enemy: CharacterBase, attack_dir: Vector2) -> bool:
	var to_target := enemy.global_position - global_position
	if to_target.length() > strike_distance * 1.5:
		return false
	return attack_dir.length_squared() <= 0.0001 or to_target.dot(attack_dir) <= 0.0

func block() -> void:
	if _state not in [State.IDLE, State.MOVING_TO_IDLE]:
		return
	_begin_action()
	_state = State.BLOCKING
	_block_absorbed = 0.0
	_play_anim(ANIM_BLOCK)
	block_started.emit()

func unblock() -> void:
	if _state != State.BLOCKING:
		return
	_block_absorbed = 0.0
	_state = State.IDLE
	_play_anim(ANIM_IDLE)
	block_ended.emit()

func take_damage(amount: float, from_position: Vector2 = Vector2.INF) -> void:
	if _state == State.DEAD:
		return
	if _invulnerable:
		_on_dodged_hit(amount, from_position)
		return
	_last_hit_from = from_position
	if _state == State.BLOCKING:
		await _on_blocked_hit(amount, from_position)
		return
	var pick := _pick_damage()
	var damage_anim: StringName = pick["anim"]
	var can_react := _state == State.IDLE or _state == State.DODGING
	if not can_react or not _has_anim(damage_anim):
		_apply_damage(amount)
		return
	var id := _begin_action()
	_state = State.HIT
	_play_anim(damage_anim)
	_apply_damage(amount)
	await _await_anim_frame(damage_anim, int(pick["frame"]), id)
	if id != _action_id:
		return
	await _await_anim_end(damage_anim, id)
	if id != _action_id:
		return

	_state = State.IDLE
	_play_anim(ANIM_IDLE)

	var return_pt := _get_post_hit_return_point()
	if return_pt != Vector2.INF and global_position.distance_to(return_pt) > 2.0:
		var speed_px := maxf(character_stats.speed, 0.01) * pixels_per_unit
		await _move_to(return_pt, speed_px, id)

func move_to_idle_point(duration: float = 0.3) -> void:
	if _state not in [State.IDLE, State.MOVING_TO_IDLE]:
		return
	var id := _begin_action()
	_state = State.MOVING_TO_IDLE
	if not (await _tween_self_to(idle_point, duration, id, Tween.EASE_IN_OUT)):
		return
	_state = State.IDLE
	_play_anim(ANIM_IDLE)
	turn_finished.emit()

func heal(amount: float) -> void:
	if _state == State.DEAD or amount <= 0.0:
		return
	var old := health
	health = minf(character_stats.max_health, health + amount)
	if not is_equal_approx(health, old):
		healed.emit(health - old)

# ── ability selection ──

func has_usable_ability() -> bool:
	if weapon == null:
		return false
	for ab in weapon.abilities:
		if ab == null:
			continue
		if not ab.can_use(current_ap):
			continue
		if _has_anim(ab.get_animation_name(0)):
			return true
	return false

func _pick_ability() -> Ability:
	if weapon == null or weapon.abilities.is_empty():
		return null
	var available: Array[Ability] = []
	var total_weight := 0.0
	for ab in weapon.abilities:
		if ab == null:
			continue
		if not ab.can_use(current_ap):
			continue
		if not _has_anim(ab.get_animation_name(0)):
			continue
		available.append(ab)
		total_weight += _ability_weight(ab.name)
	if available.is_empty():
		return null
	if total_weight <= 0.0:
		return available.pick_random()
	var roll := randf() * total_weight
	for ab in available:
		roll -= _ability_weight(ab.name)
		if roll <= 0.0:
			return ab
	return available[available.size() - 1]

func _ability_weight(ability_name: StringName) -> float:
	return float(_attack_weights.get(ability_name, 1.0))

func _resolve_attack_anim(ability: Ability) -> StringName:
	var variant := randi() % maxi(ability.animation_variants, 1)
	var anim := ability.get_animation_name(variant)
	if not _has_anim(anim) and _has_anim(ability.animation_name):
		anim = ability.animation_name
	return anim

# ── hooks for subclasses ──

func _should_prepare_before_approach() -> bool:
	return false

func _approach_speed_mult() -> float:
	return 1.0

func _resolve_strike_anchor(enemy: CharacterBase) -> Vector2:
	return enemy.get_strike_anchor() if enemy.has_method("get_strike_anchor") else enemy.global_position

func get_strike_anchor() -> Vector2:
	return idle_point if _state in [State.IDLE, State.DODGING, State.MOVING_TO_IDLE] else global_position

func _pick_damage() -> Dictionary:
	return {"anim": ANIM_DAMAGE, "frame": animation_frame_damage}

func _after_block_hit() -> void:
	if block_max_absorbed_damage > 0.0 and _block_absorbed >= block_max_absorbed_damage:
		unblock()

func _on_dodged_hit(amount: float, from_position: Vector2) -> void:
	_trigger_dodge_hitstop(amount)
	attack_dodged.emit(amount)

func _hide_ui_on_death() -> void:
	pass

func _get_post_hit_return_point() -> Vector2:
	return Vector2.INF

# ── action lifecycle ──

func _begin_action() -> int:
	_kill_tween(_active_tween)
	_action_id += 1
	return _action_id

func _wait_tween(tw: Tween, id: int) -> void:
	await get_tree().process_frame
	while id == _action_id and tw.is_valid() and tw.is_running():
		await get_tree().process_frame

func _tween_self_to(pos: Vector2, duration: float, id: int, ease: Tween.EaseType = Tween.EASE_OUT) -> bool:
	_active_tween = create_tween()
	_active_tween.set_trans(Tween.TRANS_QUAD).set_ease(ease)
	_active_tween.tween_property(self, "global_position", pos, duration)
	await _wait_tween(_active_tween, id)
	return id == _action_id

func _move_to(pos: Vector2, speed_px: float, id: int) -> bool:
	var t := clampf(global_position.distance_to(pos) / speed_px, min_phase_duration, max_phase_duration)
	return await _tween_self_to(pos, t, id)

# ── juice: attack ──

func _tween_sprite_offset(offset: Vector2, out_time: float, back_time: float, trans: Tween.TransitionType = Tween.TRANS_QUAD) -> void:
	if not animated_sprite:
		return
	_kill_tween(_recoil_tween)
	_recoil_tween = create_tween()
	_recoil_tween.set_trans(trans).set_ease(Tween.EASE_OUT)
	_recoil_tween.tween_property(animated_sprite, "position", _sprite_base_position + offset, out_time)
	_recoil_tween.tween_property(animated_sprite, "position", _sprite_base_position, back_time)

func _play_attack_lunge(dir: Vector2) -> void:
	if attack_lunge_distance <= 0.0:
		return
	_tween_sprite_offset(-dir * attack_lunge_distance, 0.06, 0.08, Tween.TRANS_SINE)

func _play_attack_recoil(dir: Vector2) -> void:
	if attack_recoil_distance <= 0.0:
		return
	_tween_sprite_offset(dir * attack_recoil_distance, 0.05, 0.10)

# ── damage ──

func _apply_damage(amount: float, flash: bool = true) -> void:
	health = maxf(0.0, health - amount)
	var will_die := health <= 0.0
	# Летальный удар заменяет обычный хитстоп death-версией (не суммируются).
	if will_die:
		_trigger_death_hitstop(amount)
	else:
		_trigger_hitstop(amount)
	damaged.emit(amount)
	if will_die:
		_die()
		return
	if flash:
		_flash(flash_color, flash_in_duration, flash_out_duration)
	_play_hit_shake(_last_hit_from)

func _die() -> void:
	if _state == State.DEAD:
		return
	_state = State.DEAD
	_invulnerable = false
	_block_absorbed = 0.0
	_begin_action()
	for tw in [_hit_shake_tween, _flash_tween, _idle_bob_tween, _recoil_tween]:
		_kill_tween(tw)
	if animated_sprite:
		animated_sprite.position = _sprite_base_position
		animated_sprite.modulate = Color.WHITE
	_hide_ui_on_death()
	_play_anim(ANIM_DEATH)
	if not death_disappear:
		add_to_group(CORPSE_GROUP)
	died.emit()
	_start_death_knockback()
	_start_death_fade()

# ── hit reaction ──

func _resolve_hit_shake(preset_override: int = -1) -> Array:
	var preset: int = preset_override if preset_override >= 0 else hit_shake_preset
	if preset == HitShakePreset.CUSTOM:
		return [hit_shake_distance, hit_shake_duration, hit_shake_oscillations, hit_shake_decay, hit_shake_return_mult]
	return HIT_SHAKE_PRESETS.get(preset, HIT_SHAKE_PRESETS[HitShakePreset.MEDIUM])

func _play_hit_shake(from_position: Vector2, distance_override: float = -1.0, preset_override: int = -1) -> void:
	if not animated_sprite or _state == State.DEAD:
		return
	var p := _resolve_hit_shake(preset_override)
	var distance: float = distance_override if distance_override >= 0.0 else p[0]
	var duration: float = p[1]
	var oscillations: int = maxi(1, p[2])
	var decay: float = p[3]
	var return_mult: float = p[4]
	if hit_shake_distance_jitter > 0.0:
		distance *= randf_range(1.0 - hit_shake_distance_jitter, 1.0 + hit_shake_distance_jitter)
	if hit_shake_duration_jitter > 0.0:
		duration *= randf_range(1.0 - hit_shake_duration_jitter, 1.0 + hit_shake_duration_jitter)
	if hit_shake_decay_jitter > 0.0:
		decay = clampf(decay + randf_range(-hit_shake_decay_jitter, hit_shake_decay_jitter), 0.0, 1.0)
	var dir := _dir_from(from_position, Vector2.UP)
	_kill_tween(_hit_shake_tween)
	_hit_shake_tween = create_tween()
	_hit_shake_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	var half_steps := oscillations * 2
	var step_duration := maxf(duration / float(half_steps + 1), 0.01)
	var amp := distance
	for i in range(half_steps):
		var target := _sprite_base_position + dir * amp if i % 2 == 0 else _sprite_base_position - dir * amp
		var tw := _hit_shake_tween.tween_property(animated_sprite, "position", target, step_duration)
		if i == 0:
			tw.set_ease(Tween.EASE_OUT)
		amp *= decay
	_hit_shake_tween.tween_property(
		animated_sprite, "position", _sprite_base_position, maxf(step_duration * return_mult, 0.01)
	).set_ease(Tween.EASE_OUT)

func _flash(color: Color, in_duration: float, out_duration: float) -> void:
	if not animated_sprite or _state == State.DEAD:
		return
	_kill_tween(_flash_tween)
	_flash_tween = create_tween()
	_flash_tween.tween_property(animated_sprite, "modulate", color, in_duration)
	_flash_tween.tween_property(animated_sprite, "modulate", Color.WHITE, out_duration)

# ── block ──

func play_block_reaction(amount: float, from_position: Vector2 = Vector2.INF) -> void:
	if _state == State.DEAD:
		return
	_play_anim(ANIM_BLOCK)
	hit_blocked.emit(amount)
	_flash(block_flash_color, block_flash_in_duration, block_flash_out_duration)
	_play_hit_shake(from_position, block_shake_distance, HitShakePreset.BLOCK_HIT)
	if block_recoil_distance > 0.0:
		_tween_sprite_offset(_dir_from(from_position, Vector2.UP) * block_recoil_distance, 0.05, 0.12)

func _get_anim_frame_time(anim: StringName, frame: int) -> float:
	if not _has_anim(anim) or frame <= 0:
		return 0.0
	var speed := animated_sprite.sprite_frames.get_animation_speed(anim)
	return float(frame) / speed if speed > 0.0 else 0.0

func _on_blocked_hit(amount: float, from_position: Vector2) -> void:
	var leaked := maxf(0.0, amount - get_block_damage_reduction())
	var absorbed := amount - leaked
	_block_absorbed += absorbed
	if absorbed > 0.0:
		_trigger_block_hitstop(absorbed)
	await play_block_reaction(amount, from_position)
	if _state == State.DEAD:
		return
	if leaked > 0.0:
		_apply_damage(leaked, false)
	_after_block_hit()

# ── death movement ──

func _start_death_knockback() -> void:
	var base_dir := _dir_from(_last_hit_from, Vector2.UP)
	var land := _find_corpse_landing(base_dir)
	_corpse_landing_pos = land
	z_index = death_flying_z
	var fly_duration := maxf(global_position.distance_to(land) / maxf(death_knockback_speed, 1.0), min_phase_duration)
	var knockback := create_tween()
	knockback.set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	knockback.tween_property(self, "global_position", land, fly_duration)
	if animated_sprite and death_arc_height > 0.0:
		var arc := create_tween()
		arc.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
		arc.tween_property(animated_sprite, "position", _sprite_base_position + Vector2(0.0, -death_arc_height), fly_duration * 0.4)
		arc.tween_property(animated_sprite, "position", _sprite_base_position, fly_duration * 0.6)
	if not death_disappear:
		_drop_z_when_death_settled(knockback)

func _drop_z_when_death_settled(knockback_tween: Tween) -> void:
	if knockback_tween and knockback_tween.is_valid() and knockback_tween.is_running():
		await knockback_tween.finished
	if _state != State.DEAD:
		return
	await _await_death_anim_last_frame()
	if _state == State.DEAD:
		z_index = _compute_corpse_z()

func _compute_corpse_z() -> int:
	if death_corpse_z_sort_span <= 0:
		return death_corpse_z
	var y_range := _resolve_corpse_sort_y_range()
	if y_range.y <= y_range.x:
		return death_corpse_z
	var t := clampf(inverse_lerp(y_range.x, y_range.y, _corpse_landing_pos.y), 0.0, 1.0)
	return maxi(death_corpse_z - int(round((1.0 - t) * float(death_corpse_z_sort_span))), -4096)

func _resolve_corpse_sort_y_range() -> Vector2:
	if death_corpse_sort_y_range.y > death_corpse_sort_y_range.x:
		return death_corpse_sort_y_range
	var bounds := _resolve_landing_bounds()
	return Vector2(bounds.position.y, bounds.end.y) if bounds.size.y > 0.0 else Vector2.ZERO

func _await_death_anim_last_frame() -> void:
	if not _has_anim(ANIM_DEATH):
		return
	if not animated_sprite or animated_sprite.animation != ANIM_DEATH:
		return
	var last_frame := maxi(animated_sprite.sprite_frames.get_frame_count(ANIM_DEATH) - 1, 0)
	if animated_sprite.frame >= last_frame:
		return
	var elapsed := 0.0
	while animated_sprite.animation == ANIM_DEATH and animated_sprite.is_playing():
		if animated_sprite.frame >= last_frame:
			return
		await animated_sprite.frame_changed
		elapsed += get_process_delta_time()
		if elapsed > ANIM_WAIT_TIMEOUT:
			push_warning("Death anim не дошла до последнего кадра за %.1fs на %s" % [ANIM_WAIT_TIMEOUT, name])
			return

func _find_corpse_landing(base_dir: Vector2) -> Vector2:
	var corpses := get_tree().get_nodes_in_group(CORPSE_GROUP)
	var bounds := _resolve_landing_bounds()
	var best := global_position + base_dir * death_knockback_distance
	var best_min_dist := -1.0
	for _attempt in death_landing_attempts:
		var angle := randf_range(-death_knockback_angle_jitter, death_knockback_angle_jitter) if death_knockback_angle_jitter > 0.0 else 0.0
		var dist := death_knockback_distance
		if death_knockback_distance_jitter > 0.0:
			dist *= randf_range(1.0 - death_knockback_distance_jitter, 1.0 + death_knockback_distance_jitter)
		var candidate := global_position + base_dir.rotated(angle) * dist
		if bounds.size != Vector2.ZERO:
			candidate = _clamp_to_rect(candidate, bounds)
		var min_dist := _min_dist_to_corpses(candidate, corpses)
		if min_dist >= death_min_corpse_distance:
			return candidate
		if min_dist > best_min_dist:
			best_min_dist = min_dist
			best = candidate
	return best

func _min_dist_to_corpses(pos: Vector2, corpses: Array) -> float:
	var min_dist := INF
	for corpse in corpses:
		if corpse == self or not is_instance_valid(corpse):
			continue
		var cp: Vector2 = corpse.get_corpse_anchor() if corpse.has_method("get_corpse_anchor") else corpse.global_position
		min_dist = minf(min_dist, pos.distance_to(cp))
	return min_dist

func _resolve_landing_bounds() -> Rect2:
	if death_landing_bounds.size != Vector2.ZERO:
		return death_landing_bounds
	var viewport := get_viewport()
	if viewport == null:
		return Rect2()
	var inner := Rect2(
		viewport.get_visible_rect().position + death_landing_viewport_pad,
		viewport.get_visible_rect().size - death_landing_viewport_pad * 2.0
	)
	return inner if inner.size.x > 0.0 and inner.size.y > 0.0 else Rect2()

func _clamp_to_rect(pos: Vector2, rect: Rect2) -> Vector2:
	return Vector2(
		clampf(pos.x, rect.position.x, rect.end.x),
		clampf(pos.y, rect.position.y, rect.end.y)
	)

func _start_death_fade() -> void:
	if not death_disappear and is_equal_approx(death_corpse_alpha, 1.0):
		return
	var fade := create_tween()
	if death_fade_delay > 0.0:
		fade.tween_interval(death_fade_delay)
	if death_disappear:
		fade.tween_property(self, "modulate:a", 0.0, maxf(death_fade_duration, 0.01))
		fade.tween_callback(queue_free)
	elif death_fade_duration > 0.0:
		fade.tween_property(self, "modulate:a", death_corpse_alpha, death_fade_duration)
	else:
		modulate.a = death_corpse_alpha

# ── animation helpers ──

func _play_anim(anim: StringName) -> void:
	if not _has_anim(anim):
		return
	if animated_sprite.animation == anim and animated_sprite.is_playing():
		return
	animated_sprite.play(anim)

func _has_anim(anim: StringName) -> bool:
	return animated_sprite != null and animated_sprite.sprite_frames != null and animated_sprite.sprite_frames.has_animation(anim)

func _warn_anim_timeout(msg: String) -> void:
	push_warning(msg)
	if animated_sprite:
		animated_sprite.stop()

func _await_anim_end(anim: StringName, id: int) -> void:
	if not _has_anim(anim):
		return
	var elapsed := 0.0
	while id == _action_id and animated_sprite.animation == anim and animated_sprite.is_playing():
		await get_tree().process_frame
		elapsed += get_process_delta_time()
		if elapsed > ANIM_WAIT_TIMEOUT:
			_warn_anim_timeout("Anim '%s' не завершилась за %.1fs на %s (looped?)" % [anim, ANIM_WAIT_TIMEOUT, name])
			return

func _await_anim_frame(anim: StringName, frame: int, id: int) -> void:
	if not _has_anim(anim) or frame <= 0:
		return
	var target := clampi(frame, 0, maxi(animated_sprite.sprite_frames.get_frame_count(anim) - 1, 0))
	var elapsed := 0.0
	while id == _action_id and animated_sprite.animation == anim and animated_sprite.is_playing():
		if animated_sprite.frame >= target:
			return
		await animated_sprite.frame_changed
		elapsed += get_process_delta_time()
		if elapsed > ANIM_WAIT_TIMEOUT:
			_warn_anim_timeout("Anim '%s' не достигла кадра %d за %.1fs на %s" % [anim, target, ANIM_WAIT_TIMEOUT, name])
			return

# ── UI helpers ──

func _init_bar(bar: HealthBar, value: float, max_value: float) -> void:
	if bar:
		bar.setup(value, max_value)

func _sync_bar(bar: HealthBar, value: float, max_value: float) -> void:
	if bar:
		bar.update_value(value, max_value)

# ── generic helpers ──

func _dir_from(from: Vector2, fallback: Vector2 = Vector2.UP) -> Vector2:
	if from == Vector2.INF:
		return fallback
	var d := global_position - from
	return d.normalized() if d.length_squared() > 0.0001 else fallback

func _safe_dir(v: Vector2, fallback: Vector2 = Vector2.RIGHT) -> Vector2:
	return v.normalized() if v.length_squared() > 0.0001 else fallback

func _kill_tween(tw: Tween) -> void:
	if tw and tw.is_valid():
		tw.kill()
